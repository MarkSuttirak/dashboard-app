import React from "react";

const AppsPage = () => {
    return (
        <div className="page-section">
            <h1>Test Page</h1>
        </div>
    )
}

export default AppsPage;